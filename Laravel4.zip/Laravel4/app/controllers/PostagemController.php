﻿<?php 

use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;

class PostagemController extends BaseController{
	
	//Regra para validação genérica
	private $rules = array('titulo' => 'required|min:3|max:100', 'conteudo' => 'required|min:5|max:500' );

   public function getIndex(){
	  //$postagens = PostagemDados::get(); 
	 //$postagens = DB::table('postagens')
	                                   //->where('id_postagens', '!=', '8')
									   //->where('id_postagens', '8')
									   //->orwhere('id_postagens', '8')
									   //->get(); 
	 //dd() = debug da variável
	 ///dd($postagens);
	 $postagens = DB::table('postagens')->get();

	 $titulo = 'Lista Postagens - EspecializaTI';
	 return View::make('postagem.lista', compact('postagens', 'titulo') );
   }
    
	 /*public function getAdicionar(){
	 return View::make('postagem.cadastra');
   }
   
   public function postCadastrar(){
	 $postagem = new PostagemDados();
	 $postagem->titulo = Input::get('titulo');
	 $postagem->conteudo = Input::get('conteudo');
	 $postagem->save();
	 
	 return Redirect::to('postagem');
   }*/
   public function getAdicionar(){
   	 $titulo = 'Adicionar Postagens - EspecializaTI';
   	 $tituloMostra = 'Adicionar Postagens';
	 return View::make('postagem.new-crud', compact('titulo', 'tituloMostra'));
   }
   public function postCadastrar(){
	 //$postagem = new PostagemDados();
	 //$postagem->titulo = Input::get('titulo');
	 //$postagem->conteudo = Input::get('conteudo');
	 //$postagem->save();
	 $dadosFormulario = Input::all(); //Pega campos do formulario
	 
	 $validator = Validator::make($dadosFormulario, $this->rules); //Executa as regras de validação
	 
	 if($validator->fails() ){//Se houver falha nas regras de validação
	 	return Redirect::to('postagem/adicionar') //add mensagem na pagina postagem/adicionar
	 	->withErrors($validator) // carrega a mensagem de erros do validador
	 	->withInput(); // mantem os campos do formulário preenchido
	 }
	 
	 $postagem = new PostagemDados($dadosFormulario); //Add no BD (Models/PostagemDados)
	 $postagem->save();
	 return Redirect::to('postagem');
   }
   
   public function getEditar($id_postagem){
   	   $titulo = 'Editar Postagens - EspecializaTI';
   	   $tituloMostra = 'Alterar Postagens';
	   $postagem = postagemDados::find($id_postagem);
	   //$postagem = DB::table('postagens')->where('id_postagem',$id_postagem)->get(); 
	   // $postagem = $postagem[0]; //Seta o array na posição do link correspondente da postagem.lista
	   //dd($postagem);
	   $titulo = 'Editar Postagens - EspecializaTI';
	   return View::make('postagem.new-crud', compact('postagem','titulo', 'tituloMostra'));
   }
   public function postEditar($id_postagem){
      //$postagem = postagemDados::find($id_postagem);
	  //$postagem->titulo = Input::get('titulo');
	  //$postagem->conteudo = Input::get('conteudo');
	  //$postagem->save();
	  $dadosFormulario = Input::all(); //Pega campos do formulario
	  
	  $validator = Validator::make($dadosFormulario, $this->rules); //Executa as regras de validação
	  
	  if($validator->fails() ){//Se houver falha nas regras de validação
	  	return Redirect::to("postagem/editar/{$id_postagem}") //add mensagem na pagina postagem/adicionar
	  	->withErrors($validator) // carrega a mensagem de erros do validador
	  	->withInput(); // mantem os campos do formulário preenchido
	  }
	  
	  $postagem = postagemDados::find($id_postagem);
	  $postagem->__construct($dadosFormulario); //Update no BD (Models/PostagemDados)
	  $postagem->save();
	  return Redirect::to('postagem');
   }
   
   public function getDeletar($id_postagem){
	 $postagem = postagemDados::find($id_postagem);
	 $postagem->delete();
	 return Redirect::to('postagem');
   }
   
   public function MissingMethod($params = array()){
     return "Nada encontrado :-)";
   }
}

