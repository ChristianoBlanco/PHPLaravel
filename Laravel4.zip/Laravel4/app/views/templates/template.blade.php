<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>{{$titulo or 'Especializa Postagem - Foco-Força-Fé'}}</title>

    {{HTML::style('assets/css/bootstrap.css') }} 
    {{HTML::style('assets/css/style.css') }}
</head>

<body>

    <header>
        {{HTML::image('assets/imagens/logo1.png', 'Logo topo', array('class'=>'img-logo-topo'))}}
    </header>
    <div class="content container">
        @yield('content')
        <!-- Toda tag do Blade Laravel começa com '@' -->
        <!-- @yield('content') comando laravel qeu indica variavel que vai receber itens de outros arquivos  -->
    </div>

    <footer>
        Footer da aplicação
    </footer>

</body>

</html>
