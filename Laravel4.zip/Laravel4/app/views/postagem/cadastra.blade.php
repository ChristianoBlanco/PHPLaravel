﻿@extends('templates.template')

@section('content')
  <h1>Cadastrar Postagem</h1>
  <br>
  {{Form::open(array('url' => 'postagem/cadastrar'))}}
  <br>
    {{Form::text('titulo', '' , array('placeholder' => 'Titulo'))}}
  <br><br>  
    {{Form::textarea('conteudo' , '' , array('placeholder' => 'Conteudo'))}}
  <br>  
    {{Form::submit('Cadastrar')}}
  <br>  
  {{Form::close()}}
@stop