@extends('templates.template')

@section('content')
  <h3>{{$tituloMostra or 'Gestão de postagens-CRUD' }}</h3>
  <a href="{{url('postagem')}}" title='Voltar'>
    <span class="glyphicon glyphicon-share-alt"></span>
  </a>
  @if( count($errors) > 0 ) 
  <div class="alert alert-danger">
   @foreach($errors->all() as $msg)
    <p>{{$msg}}</p>
   @endforeach
  </div>
  @endif
 

  @if( isset($postagem->id_postagem) )
  {{Form::open(array('url' => "postagem/editar/$postagem->id_postagem"))}}
  @else
  {{Form::open(array('url' => 'postagem/cadastrar'))}}
  @endif
  
    <div class="form-group">
    {{Form::text('titulo'       , isset($postagem->titulo) ? $postagem->titulo : ''  , array('placeholder' => 'Titulo','class' => 'form-control'))}}
    </div>
    {{Form::textarea('conteudo' , isset($postagem->conteudo) ? $postagem->conteudo : '' , array('placeholder' => 'Conteudo' ,'class' => 'form-control' ))}}
    
    {{Form::submit('Cadastrar', array('class' => 'btn btn-default'))}}
    
  {{Form::close()}}
  
@stop