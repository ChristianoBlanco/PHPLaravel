﻿<?php

//A "extends Eloquent" faz todo serviço de MODELAGEM do Banco de Dados
class postagemDados extends Eloquent{
	
protected $table = 'postagens';

protected $primaryKey = 'id_postagem';

protected $guarded = array('id_postagem');

}