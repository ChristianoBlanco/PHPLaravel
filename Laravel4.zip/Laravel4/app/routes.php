<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/
/*Route::get('postagens', function(){
 return "Listando as Postagens";	
});*/
/*Route::get('postagem/adicionar', function(){
 return "Adicionando postagem";	
});*/
/*Route::get('postagem/editar{id_postagem?}/categoria/{teste?}', function($id_postagem = '', $teste = null){
 return "Editar postagem {$id_postagem}, {$teste}";	
});*/
/*Route::get('postagem/deletar{id_postagem?}', function($id_postagem = ''){
 return "Deletar postagem {$id_postagem}";	
});*/
/*Route::group(array('prefix' => 'painel' , 'before' => 'filtroteste'), function(){																		
     Route::get('usuarios', function()
      {
	    return 'Lista usuarios';
     });
	 Route::get('newsletter', function()
      {
	    return 'Lista newsletter';
     });
	 Route::get('produtos', function()
      {
	    return 'Lista produtos';
     });
});
Route::get('login', function()
{
 return "Formuário de login";	
});*/
//Implicit Controllers
Route::controller('postagem', 'PostagemController');
//Route::get('postagem/adicionar', 'PostagemController@AdicionarProdutos');	

Route::get('/', function()
{
	//return View::make('hello');
	return Redirect::to('postagem');
});
