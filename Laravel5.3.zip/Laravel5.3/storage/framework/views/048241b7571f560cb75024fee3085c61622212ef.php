<?php $__env->startSection('content'); ?>
<h1 class="titulo-pg">Cadastro de Produtos</h1>
<?php if(isset($errors) and count($errors) > 0): ?>
  <div class="alert alert-danger">  
     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <p><?php echo e($error); ?></p>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
<?php endif; ?>

<form name="form1" action="<?php echo e(route('produtos.store')); ?>" method="post" class="form">
    <?php echo csrf_field(); ?>

    
  
  <div class="form-group">
   <input type="text" name="nome" value="<?php echo e(old('nome')); ?>" placeholder="Nome do produto" class="form-control"> 
  </div> 
  <div class="form-group">
    <label>
      <input type="checkbox" name="ativo" value="1">
       Ativo?
   </label>
  </div>
  <div class="form-group">  
  <input type="text" name="numero"  value="<?php echo e(old('numero')); ?>" placeholder="Entre com a Qtd." class="form-control">
  </div>
  <div class="form-group">  
  <select name="categoria" class="form-control">
      <option value="">Escolha a categoria</option>
      <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorias): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($categorias); ?>"><?php echo e($categorias); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  </div>
  <div class="form-group">  
  <textarea name="descricao"  placeholder="Descrição:" class="form-control"><?php echo e(old('descricao')); ?></textarea>
  </div>
  <button class="btn btn-primary">Enviar</button>
</form>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('painel.templates.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>