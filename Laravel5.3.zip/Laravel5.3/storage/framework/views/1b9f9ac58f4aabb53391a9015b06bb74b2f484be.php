<?php $__env->startSection('content'); ?>

<h1>Home Page Teste Site</h1>
<?php echo e(isset($teste) ? $teste : 'Não existe'); ?>

<br>
<?php if($var1 == '1123'): ?>
 <p>É igual a 123 :)</p>
<?php else: ?>
 <p>É diferte :/</p>
<?php endif; ?>

<?php if (! ($var1 == '1234')): ?>
<p>Não é verdadeiro</p>
<?php endif; ?>

<?php for($i=0; $i < 10; $i++ ): ?>

<p>Valor de i: <?php echo e($i); ?></p>

<?php endfor; ?>


<?php $__empty_1 = true; $__currentLoopData = $arrayData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $array): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <p><?php echo e($array); ?></p>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<p>Não exitem intens para serem impresssos </p>
<?php endif; ?>

<?php 

 ?>

<?php echo $__env->make('Site.Includes.sidebar', compact('var1'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" 
href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" 
crossorigin="anonymous">
 
<?php $__env->stopPush(); ?>

<?php echo $__env->make('Site.Template.template1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>