<?php $__env->startSection('content'); ?>

<h1>Contato Teste Site</h1>

{Teste de contato}

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Site.Template.template1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>