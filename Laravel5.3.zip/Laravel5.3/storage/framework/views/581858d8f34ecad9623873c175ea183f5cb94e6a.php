<?php $__env->startSection('content'); ?>

<h1>Categoria Teste Site</h1>

{Testando Categoria Laravel}

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Site.Template.template1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>