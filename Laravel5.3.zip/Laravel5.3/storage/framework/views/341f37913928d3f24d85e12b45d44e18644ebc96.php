<h1>Home Page Teste Site</h1>
<?php echo e($teste); ?><br>
<?php echo e($teste2); ?><br>
<?php echo e($teste3); ?>