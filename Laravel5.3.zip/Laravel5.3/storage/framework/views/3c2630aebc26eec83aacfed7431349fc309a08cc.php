<?php $__env->startSection('content'); ?>
<h1 class="titulo-pg">
    <a href="<?php echo e(route('produtos.index')); ?>"><span class="glyphicon glyphicon-fast-backward"></span></a>
    Produto: <b><?php echo e(isset($produto->nome) ? $produto->nome : 'Nenhum'); ?></b>
</h1>
<p><b>Ativo:</b> <?php echo e($produto->ativo); ?></p>
<p><b>Nome:</b> <?php echo e($produto->nome); ?></p>
<p><b>Qtd:</b> <?php echo e($produto->numero); ?></p>
<p><b>Categoria:</b> <?php echo e($produto->categoria); ?></p>
<p><b>Descrição:</b> <?php echo e($produto->descricao); ?></p>

<?php if(isset($errors) and count($errors) > 0): ?>
  <div class="alert alert-danger">  
     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <p><?php echo e($error); ?></p>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
<?php endif; ?>
<hr>

<?php echo Form::open(['route'=> ['produtos.destroy', $produto->id], 'method'=>'DELETE']); ?>

  <?php echo Form::submit("Deletar produto: $produto->nome", ['class'=>'btn btn-danger']); ?>

<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Painel.templates.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>