<?php $__env->startSection('content'); ?>
<h1 class="titulo-pg">Listagem dos produtos</h1>

<!-- a href="<?php echo e(route('produtos.create')); ?>" class="btn btn-primary btn-add" -->
<a href="<?php echo e(url('painel/produtos/create')); ?>" class="btn btn-primary btn-add">
    <span class="glyphicon glyphicon-plus"></span> Cadastrar
</a>

<table class="table table-striped">
    <tr>
        <th>Nome</th>
        <th>Descrição</th>
        <th width="100px">Ações</th>
    </tr>
    
    <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <tr>  
      <td><?php echo e($produto->nome); ?></td>
      <td><?php echo e($produto->descricao); ?></td>
      <td>
          <a href="<?php echo e(route('produtos.edit',$produto->id )); ?>" class="action edit">
              <span class=" glyphicon glyphicon-pencil"></span>
          </a>
          <a href="<?php echo e(route('produtos.show', $produto->id)); ?>" class="action delete">
              <span class="glyphicon glyphicon-eye-open"></span>
          </a>
      </td>
     </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</table>
<?php echo $produtos->links(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Painel.templates.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>