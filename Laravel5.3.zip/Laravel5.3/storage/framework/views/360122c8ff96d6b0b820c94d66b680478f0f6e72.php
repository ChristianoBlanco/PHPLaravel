<?php $__env->startSection('content'); ?>

<h1>Home Page Teste Site</h1>
<?php echo e($teste); ?><br>
<?php echo e($teste2); ?><br>
<?php echo e($teste3); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Site.Template.template1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>