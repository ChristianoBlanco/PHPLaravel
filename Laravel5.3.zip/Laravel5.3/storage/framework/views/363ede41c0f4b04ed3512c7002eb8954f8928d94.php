#sidebar
<?php echo e(isset($var1) ? $var1 : ''); ?>