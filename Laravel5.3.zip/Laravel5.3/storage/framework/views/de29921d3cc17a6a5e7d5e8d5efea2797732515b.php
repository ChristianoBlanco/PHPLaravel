<!-- FORMULARIO FEITO UTILIZANDO: LARAVEL COLLECTIVE:https://laravelcollective.com -->


<?php $__env->startSection('content'); ?>
<h1 class="titulo-pg">
    <a href="<?php echo e(route('produtos.index')); ?>"><span class="glyphicon glyphicon-fast-backward"></span></a>
    Gestão Produto: <b><?php echo e(isset($produto->nome) ? $produto->nome : 'Novo'); ?></b>
</h1>
<?php if(isset($errors) and count($errors) > 0): ?>
  <div class="alert alert-danger">  
     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <p><?php echo e($error); ?></p>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
<?php endif; ?>

<?php if(isset($produto)): ?>
  <?php echo Form::model($produto,['route'=> ['produtos.update', $produto->id], 'class'=>'form', 'method'=>'put' ]); ?> 
<?php else: ?>
  <?php echo Form::open(['route'=>'produtos.store','class'=>'form']); ?>

<?php endif; ?>

   
    
  <div class="form-group"> 
   <?php echo Form::text('nome', null, ['class'=>'form-control', 'placeholder'=>'Nome do produto']); ?>

  </div> 
  <div class="form-group">
    <label>
       Ativo?
     <?php echo Form::checkbox('ativo'); ?>

   </label>
  </div>
  <div class="form-group">  
  <input type="text" name="numero"  value="<?php echo e(isset($produto->numero) ? $produto->numero : old('numero')); ?>" placeholder="Entre com a Qtd." class="form-control">
  </div>
  <div class="form-group">  
  <select name="categoria" class="form-control">
      <option value="">Escolha a categoria</option>
      <?php $__currentLoopData = $categoria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorias): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($categorias); ?>"
              <?php if(isset($produto) and $produto->categoria == $categorias ): ?>
                selected
              <?php endif; ?>
              
              ><?php echo e($categorias); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  </div>
  <div class="form-group">  
  <?php echo Form::textarea('descricao', null, ['class'=>'form-control', 'placeholder'=>'Descrição']); ?>

  </div>
  <?php echo Form::submit('Enviar',['class'=>'btn btn-primary']); ?>

<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('painel.templates.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>