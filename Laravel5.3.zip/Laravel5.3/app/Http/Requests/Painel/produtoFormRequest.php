<?php

namespace App\Http\Requests\Painel;

use Illuminate\Foundation\Http\FormRequest;

class produtoFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
        'nome'      =>'required|min:3|max:100',
        'numero'    =>'required|max:11|numeric',
        'categoria' =>'required',
        'descricao' =>'min:3|max:1000'
    ];
    }
    public function messages(){
        
        return [
            'nome.required'=>'Nome: Preenchimento obrigatório',
            'numero.numeric'=>'Numero: Somente números',
            'numero.required'=>'Número: Preenchimento obrigatório',
            'categoria.required'=>'Categoria: não pode ser vazio'
            ];
    }
}
