<?php

namespace App\Http\Controllers\Painel;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Painel\produto;
use App\Http\Requests\Painel\produtoFormRequest;

class ProdutoController extends Controller
{  
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    
    private $produto;
    private $totalpage = 3;
    //function __contruct =>função pré definida p gerar método p classe
    public function __construct(Produto $produto) {
      
        //Método que tbm recupera dados da tabela especiifcada 
        //no use app\models\painel\produto (ex.)
        $this->produto = $produto;
    }


    public function index(Produto $produto)
    {
        //Ou pode usa Direct Injection (exemplo acima no plublic function)
        //Ou pode chamar a tabela via clsse
        /*$produto = new produto;*/
        
        $titulo = 'Listagem dos produtos';
        //recupera todos os dados da tabla
        //$produtos = $this->produto->all();
        $produtos = $this->produto->paginate($this->totalpage);
        return view('Painel.produtos.index', compact('produtos','titulo'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $titulo = 'Cadastro de produtos';
        $categoria = ['eletronicos','moveis','limpeza','banho'];
        return view('painel.produtos.create-edit', compact('titulo','categoria'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(produtoFormRequest $request)
    {
        /*//Capitura todos os dados do formulário;
          $request->all();
          //Capitura dados selecionados do formuário;
          $request->only('nome','numero');
          //Somente os dados não selecionados serão capiturados/
          $request->except('_token');
          //Capitura apenas um campo específico do formulário;
          $request->input('nome');
        */
        
        //pega os dados do formulario;
        $dataForm = $request->all();
              
        $dataForm['ativo'] = (!isset($dataForm['ativo']))? 0 : 1;
         
        //Validar o cadastro
        //$this->validate($request, $this->produto->rules);
        /*$msg = [
            'nome.required'=>'Nome: Preenchimento obrigatório',
            'numero.numeric'=>'Numero: Somente números',
            'numero.required'=>'Número: Preenchimento obrigatório',
            'categoria.required'=>'Categoria: não pode ser vazio'
            ];
        $validate = validator($dataForm, $this->produto->rules, $msg);
        if($validate->fails()){
            return redirect()
                    ->route('produtos.create')
                    //migra os campos preenchidos
                    ->withErrors($validate)
                    ->withInput();
        } */
        //Faz o Cadastro
        $insert = $this->produto->create($dataForm);
        
        if($insert){
            return redirect()->route('produtos.index');
        }else{
           //return redirect()->back();
           return redirect()->route('prodtuos.create'); 
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        /*//outro método p recuparar dados
        $produto = $this->produto->where('id', $id)->get();*/
       
        $produto = $this->produto->find($id);
        
        $titulo = "produto: {$produto->nome}";
        
        return view('painel.produtos.show', compact('produto','titulo'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //find() recupera itens pelo valor especificado em seu campo
        $produto = $this->produto->find($id);
        
        $titulo = "Editar de produto: {produto->nome}";
        $categoria = ['eletronicos','moveis','limpeza','banho'];
        
        return view('painel.produtos.create-edit', compact('titulo','categoria','produto'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(produtoFormRequest $request, $id)
    {
        //Esse método update so recebe valor de formularios tipo PUT ou PATH
       
        //pega os dados do formulario;
        $dataForm = $request->all();
        
       //Recupera o item para fazer o update
        $produto = $this->produto->find($id);
        
        //verifica se o produto está ativado
        $dataForm['ativo'] = (!isset($dataForm['ativo']))? 0 : 1;
                
        //faz o update dos dados do formulário
        $update =  $produto->update($dataForm);
        
        //testa se o update está correto ou não e define a rota para cada situação
        if( $update){
            
          return redirect()->route('produtos.index'); 
        }else{
          return redirect()->route('produtos.edit' , $id)->with(['errors'=>'Falha ao editar']);   
        }
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $produto = $this->produto->find($id);
        
        $delete = $produto->delete();
        
        if( $delete){
         return redirect()->route('produtos.index');
        }else{
          return redirect()->route('produtos.show' , $id)->with(['errors'=>'Falha ao deletar']);  
        }   
            
    }
    
    public function tests()
    {
        //PRIMEIRO TIPO DE INSERT
        /*$prod = $this->produto;
        $prod->nome = 'nome do produto';
        $prod->numero = '123456';
        $prod->ativo = '1';
        $prod->categoria = 'eletronicos';
        $prod->descricao = 'bla bla bla';
        $insert = $prod->save();
        
        if($insert){
           return 'Inserido com sucesso!'; 
        }else{
            return 'Deu erro';
        }*/
       
        //SEGUNDO TIPO DE INSERT
        /*$insert = $this->produto->create([
                    'nome'      => 'Novo produto 2',
                    'numero'    => 24680,
                    'ativo'     => '0',
                    'categoria' => 'moveis',
                    'descricao' => 'madeira de lei 2'
                  ]);
        if($insert){
           return "Inserido com sucesso, ID: {$insert->id}"; 
        }else{
            return 'Deu erro';
        }*/
        
        //PRIMEIRO EXEMPLO UPDATE
        /*$prod = $this->produto->find(5);
        $prod->nome = 'Update de produto 2';
        $prod->numero = '13579';
        $update = $prod->save();
        if($update){
           return "Alterado com sucesso"; 
        }else{
            return 'Deu erro';
        }*/
        
        //SEGUNDO EXEMPLO UPDATE
        /*
        $prod = $this->produto->find(6);
        $update = $prod->update(
                  [
                    'nome'      => 'produto alterado',
                    'numero'    => 246,
                    'ativo'     => '1'
                  ]
                );
        if($update){
           return "Alterado com sucesso"; 
        }else{
            return 'Deu erro';
        }*/
        
        //UPDATE FEITO SEM SER PELO ID
        /*$update = $this->produto
                     ->where('numero','=',246)
                     ->update([
                         
                      'nome'      => 'produto alterado 2',
                      'numero'    => 7,
                      'ativo'     => '1',
                     ]);
        if($update){
           return "Alterado com sucesso 2"; 
        }else{
            return 'Deu erro';
        }*/
        //PRIMEIRO EXEMPLO DE DELETE
        /*$prod = $this->produto->find(3);
        $delete = $prod->delete();
        
        if($delete){
           return "Deletado com sucesso !!!"; 
        }else{
            return 'Deu erro';
        }*/
        //SEGUNDO EXEMPLO DE DELETE
        $delete = $this->produto->where('numero',7)
                                ->delete();
        
        if($delete){
           return "Deletado com sucesso 2 !!!"; 
        }else{
            return 'Deu erro';
        }
        
    }
}
