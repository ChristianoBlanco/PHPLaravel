<?php

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class SiteController extends Controller
{
    //Criando uma autenticação direta dentro do controller
    public function __construct() {
        //$this->middleware('auth');
       
        /*$this->middleware('auth')
                ->only([
                    'contato','categoria'
                ]);*/
        //cria uma excessão de NÃO  passar pelo Auth determinados funções
        /*$this->middleware('auth')
                ->except([ 
                    'index', 'categoria'
                    ]);*/
        
    }

        public function index()
     {
        /*$teste= '12345';
        $teste2 = '321';
        $teste3 = 'abcd';
        return view('Site.Home.index',compact('teste','teste2','teste3') );*/
        
        /*//Exemplo de bloqueio contrar arquivos xss
        //para imprimir jscript no nas pag blade usa-se {!! !!}
        $xss = '<script>alert("Ataque XSS");</script>'; 
        return view('Site.Home.index',compact('xss') );*/
        $xss = '<script>alert("Ataque XSS");</script>'; 
        $var1 = '123';
        $arrayData = [];
        $titulo = 'Título de Teste';
        return view('Site.Home.index',compact('titulo','xss','var1','arrayData') 
        );
        
     }
     
     public function contato()
     {
      return view('Site.Contato.contact');  
     }
     
     public function categoria($id)
     {
      return view('Site.Categoria.category');  
     }
     public function categoriaOp($id = null)
     {
      return "Categoria do site $id";  
     }
            
}
