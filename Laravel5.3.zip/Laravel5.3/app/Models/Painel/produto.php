<?php

namespace App\Models\Painel;

use Illuminate\Database\Eloquent\Model;

class produto extends Model
{
    //protected $table = '';
    
    //lista branca de array onde contém as colunas da tabela 
    //que podem ser preenchidos
    protected $fillable = [
        'nome','numero','ativo','categoria','descricao'
    ];
    //lista negra de array ontem contem as colunas da tabela 
    //que NÃO pode ser preenchidas
    //protected $guarded  = [];
    
    
}
