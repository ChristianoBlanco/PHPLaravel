<?php

/*Route::group(['prefix'=>'painel', 'middleware' => 'auth'], function(){
    Route::get('/usuarios', function () {
    return "Gestão de usuários";
    });
    Route::get('/financeiro', function () {
    return "Financeiro Painel";
    });
    Route::get('/', function () {
    return "Painel de Controle";
    });
});
Route::get('/login', function(){
    return "#formulário de Login";
});*/
/*
Route::get('/categoria/{id}', 'SiteController@categoria')=>middleware('auth');
 */
/*Route::get('/categoria2/{idCat?}', function ($idCat='AC1000') {
    return "Posts da categoria seundo exemplo $idCat";       
});
Route::get('/categoria/{idCat}', function ($idCat) {
    return "Posts da categoria $idCat";       
});*/
/*Route::get('home/nome/sobrenome/apelido', function (){
    return 'Rotas com sub rotas nomeadas...';
    
})->name('rotas.nomeadas');
Route::any('/any', function () {
    return 'página rota retornada com função any';
        
});
Route::match(['get', 'post'], '/match' ,function(){

    return 'Route match';    
});
Route::get('/contato', function () {
    return 'página Contato';
        
});
Route::get('/empresa', function () {
    //return 'página empresa';
    return view('empresa');
    
});*/
/*Route::get('/', function () {
    //return view('welcome');
    return 'Curso Laravel 5.3';
    //return redirect()->route('rotas.nomeadas');
});*/
Route::get('/painel/produtos/tests', 'Painel\ProdutoController@tests');
Route::resource('/painel/produtos',  'Painel\ProdutoController');


Route::group(['namespace' => 'Site'], function(){
Route::get('/categoria/{id}', 'SiteController@categoria');
Route::get('/categoria2/{id?}', 'SiteController@categoriaOp');
Route::get('/contato', 'SiteController@contato' );
Route::get('/', 'SiteController@index' );
});

//Auth::routes();
//Route::get('/home', 'HomeController@index')->name('home');
