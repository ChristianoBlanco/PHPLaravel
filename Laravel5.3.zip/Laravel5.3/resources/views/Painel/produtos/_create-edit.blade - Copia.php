@extends('painel.templates.template')

@section('content')
<h1 class="titulo-pg">Cadastro de Produtos</h1>
@if(isset($errors) and count($errors) > 0)
  <div class="alert alert-danger">  
     @foreach($errors->all() as $error )
     <p>{{$error}}</p>
     @endforeach
  </div>
@endif

@if(isset($produto))
<form name="form1" action="{{route('produtos.update', $produto->id )}}" method="post" class="form">
    {!! method_field('PUT') !!}
@else
<form name="form1" action="{{route('produtos.store')}}" method="post" class="form">
@endif

    {!! csrf_field() !!}
    
  <div class="form-group">
   <input type="text" name="nome" value="{{$produto->nome or old('nome')}}" placeholder="Nome do produto" class="form-control"> 
  </div> 
  <div class="form-group">
    <label>
      <input type="checkbox" name="ativo" value="1" @if(isset($produto) and $produto->ativo =='1') checked @endif>
       Ativo?
   </label>
  </div>
  <div class="form-group">  
  <input type="text" name="numero"  value="{{$produto->numero or old('numero')}}" placeholder="Entre com a Qtd." class="form-control">
  </div>
  <div class="form-group">  
  <select name="categoria" class="form-control">
      <option value="">Escolha a categoria</option>
      @foreach($categoria as $categorias)
      <option value="{{$categorias}}"
              @if(isset($produto) and $produto->categoria == $categorias )
                selected
              @endif
              
              >{{$categorias}}</option>
      @endforeach
  </select>
  </div>
  <div class="form-group">  
  <textarea name="descricao"  placeholder="Descrição:" class="form-control">{{$produto->descricao or old('descricao')}}</textarea>
  </div>
  <button class="btn btn-primary">Enviar</button>
</form>

@endsection


