@extends('Painel.templates.template')

@section('content')
<h1 class="titulo-pg">
    <a href="{{route('produtos.index')}}"><span class="glyphicon glyphicon-fast-backward"></span></a>
    Produto: <b>{{$produto->nome or 'Nenhum'}}</b>
</h1>
<p><b>Ativo:</b> {{$produto->ativo}}</p>
<p><b>Nome:</b> {{$produto->nome}}</p>
<p><b>Qtd:</b> {{$produto->numero}}</p>
<p><b>Categoria:</b> {{$produto->categoria}}</p>
<p><b>Descrição:</b> {{$produto->descricao}}</p>

@if(isset($errors) and count($errors) > 0)
  <div class="alert alert-danger">  
     @foreach($errors->all() as $error )
     <p>{{$error}}</p>
     @endforeach
  </div>
@endif
<hr>

{!! Form::open(['route'=> ['produtos.destroy', $produto->id], 'method'=>'DELETE']) !!}
  {!! Form::submit("Deletar produto: $produto->nome", ['class'=>'btn btn-danger']) !!}
{!! Form::close() !!}

@endsection