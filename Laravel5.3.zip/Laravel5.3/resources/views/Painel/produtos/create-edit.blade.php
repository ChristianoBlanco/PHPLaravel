<!-- FORMULARIO FEITO UTILIZANDO: LARAVEL COLLECTIVE:https://laravelcollective.com -->
@extends('painel.templates.template')

@section('content')
<h1 class="titulo-pg">
    <a href="{{route('produtos.index')}}"><span class="glyphicon glyphicon-fast-backward"></span></a>
    Gestão Produto: <b>{{$produto->nome or 'Novo'}}</b>
</h1>
@if(isset($errors) and count($errors) > 0)
  <div class="alert alert-danger">  
     @foreach($errors->all() as $error )
     <p>{{$error}}</p>
     @endforeach
  </div>
@endif

@if(isset($produto))
  {!! Form::model($produto,['route'=> ['produtos.update', $produto->id], 'class'=>'form', 'method'=>'put' ]) !!} 
@else
  {!! Form::open(['route'=>'produtos.store','class'=>'form']) !!}
@endif

   
    
  <div class="form-group"> 
   {!! Form::text('nome', null, ['class'=>'form-control', 'placeholder'=>'Nome do produto']) !!}
  </div> 
  <div class="form-group">
    <label>
       Ativo?
     {!! Form::checkbox('ativo') !!}
   </label>
  </div>
  <div class="form-group">  
  <input type="text" name="numero"  value="{{$produto->numero or old('numero')}}" placeholder="Entre com a Qtd." class="form-control">
  </div>
  <div class="form-group">  
  <select name="categoria" class="form-control">
      <option value="">Escolha a categoria</option>
      @foreach($categoria as $categorias)
      <option value="{{$categorias}}"
              @if(isset($produto) and $produto->categoria == $categorias )
                selected
              @endif
              
              >{{$categorias}}</option>
      @endforeach
  </select>
  </div>
  <div class="form-group">  
  {!! Form::textarea('descricao', null, ['class'=>'form-control', 'placeholder'=>'Descrição']) !!}
  </div>
  {!! Form::submit('Enviar',['class'=>'btn btn-primary']) !!}
{!! Form::close() !!}

@endsection


