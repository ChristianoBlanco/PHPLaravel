<?php

print 'Teste de View empresa.blade';

?>
