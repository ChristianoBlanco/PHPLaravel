@extends('Site.Template.template1')

@section('content')

<h1>Categoria Teste Site</h1>

{Testando Categoria Laravel}

@endsection
