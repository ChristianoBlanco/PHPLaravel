@extends('Site.Template.template1')

@section('content')

<h1>Home Page Teste Site</h1>
{{$teste or 'Não existe'}}
<br>
@if($var1 == '1123')
 <p>É igual a 123 :)</p>
@else
 <p>É diferte :/</p>
@endif

@unless($var1 == '1234')
<p>Não é verdadeiro</p>
@endunless

@for($i=0; $i < 10; $i++ )

<p>Valor de i: {{$i}}</p>

@endfor

{{--
@if( count($arrayData) > 0)
  @foreach($arrayData as $array)
    <p>{{$array}}</p>
  @endforeach
@else
  <p>Não existe itens</p>
@endif
--}}
@forelse($arrayData as $array)
  <p>{{$array}}</p>
@empty
<p>Não exitem intens para serem impresssos </p>
@endforelse

@php

@endphp

@include('Site.Includes.sidebar', compact('var1'))

@endsection

@push('scripts')
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" 
href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" 
crossorigin="anonymous">
 
@endpush
