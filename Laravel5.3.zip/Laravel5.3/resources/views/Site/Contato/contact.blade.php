@extends('Site.Template.template1')

@section('content')

<h1>Contato Teste Site</h1>

{Teste de contato}

@endsection
