<!DOCTYPE html PUBLIC>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>{{$titulo or 'Curso Laravel 5.3'}}</title>

</head>

<body>
    
    @yield('content')
    
    @stack('scripts')
</body>
</html>
