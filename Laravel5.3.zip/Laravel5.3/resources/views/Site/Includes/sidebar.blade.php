#sidebar
{{$var1 or ''}}